#ifndef TEAM_H_INCLUDED
#define TEAM_H_INCLUDED

typedef struct
{
    char name[50];
    int numPlayers;

}Team;

#endif // TEAM_H_INCLUDED
