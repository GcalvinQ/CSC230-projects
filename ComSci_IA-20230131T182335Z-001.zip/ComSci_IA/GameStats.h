#ifndef GAMESTATS_H_INCLUDED
#define GAMESTATS_H_INCLUDED

typedef struct
{
    int setNum;
    int points1;
    int points2;
    int timeOut1;
    int timeOut2;
    int subs1;
    int subs2;
}Game;

#endif // GAMESTATS_H_INCLUDED
